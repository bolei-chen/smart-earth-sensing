class Window:
    def __init__(self, start, end, size, bins):
        self.start = start
        self.end = end 
        self.size = size 
        self.values = bins[self.start:self.end] 
        self.max = len(bins)
    def shift_right(self):
        self.start += 1
        self.end += 1 
    def shift_left(self):
        self.start -= 1
        self.end -= 1 
    def over(self):
        return self.end >= self.max 
    def __str__(self):
        return "start: " + str(self.start) + "\n" + "end: " + str(self.end) + "\n" + str(self.values) + "\n"