import scipy 
import math 
''' 
alpha: varaible used for hypothesis testing 
ref_window: a reference window at current place
det_window: a detection window at current place, notice det_window.end < det_window.max 
''' 
def anomaly_detection_by_hypothesis_testing(alpha, ref_window, det_window):
    X = len(list(filter(lambda b : b == 1, ref_window.values))) 
    Y = len(list(filter(lambda b : b == 1, det_window.values))) 
    m = ref_window.size
    n = det_window.size  
    if X == 0:
        p1_hat = 0 
    else: 
        p1_hat = X / m 
    if Y == 0:
        p2_hat = 0 
    else:
        p2_hat = Y / n 
    if (X + Y) == 0:
        p_hat = 0
    else: 
        p_hat = (X + Y) / (m + n) 

    if (p1_hat - p2_hat) == 0:
        z0 = 0 
    else: 
        z0 = (p1_hat - p2_hat) / math.sqrt(p_hat * (1 - p_hat) * (1 / m + 1 / n))
    p_value = scipy.stats.norm.sf(abs(z0)) 
    return p_value < alpha 
''' 
ref_windows: a list of reference windows with number l and size n 
det_window: a detection window at current place, notice det_window.end < det_window.max
this function does not initialize the windows, it just do the check 
''' 
def anomaly_detection_by_control_charts(ref_windows, det_window):
    l = len(ref_windows) 
    n = ref_windows[0].size 
    D = len(list(filter(lambda b : b == 1, det_window.values))) 
    if D != 0:
        D /= det_window.size 
    Y_bar = sum(list(map(lambda w : get_fi(w), ref_windows))) 
    if Y_bar != 0:
        Y_bar /= l 
    if D == 0:
        return 0 > Y_bar + 3 * math.sqrt(1  / (4 * n)) 
    return math.sin(math.sqrt(D)) ** (-1) > Y_bar + 3 * math.sqrt(1  / (4 * n)) 
         
''' 
helper function for anomaly_detection_by_control charts 
''' 
def get_fi(window):
    p = len(list(filter(lambda b : b == 1, window.values))) 
    if p != 0:
        p /= window.size 
    if p == 0:
        return 0 
    return (math.sin(math.sqrt(p))) ** (-1)
 