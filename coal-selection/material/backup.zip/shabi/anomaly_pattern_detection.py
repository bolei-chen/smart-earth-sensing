from anomaly_detection_ht_cc import * 
from clustering_based_outlier_detection import * 
from window import Window 
 
''' 
X: X is the training set 
z: z is the testing set
k: k is the number of clusters, notice this can greatly increase training time
n: n is the window size 
alpha: alpha is the varaible used for hypothesis testing 
s: the minimum number of samples in a cluster 
'''
def anomaly_pattern_detection(X, z, k, s, alpha, n):
    print("clustering based outlier detection...") 
    binary_preds = clustering_based_outlier_detection(X, z, k, s)
    ''' 
    now we want to initialize all the windows for both 
    hypothesis testing and control charts 
    ''' 
    # these windows are for hypothesis testing 
    ht_ref_window = Window(start=0, size=n, end=n, bins=binary_preds) 
    ht_det_window = Window(start=0, size=n, end=n, bins=binary_preds) 

     
    # these windows are for control charts 
    # l is the length of the reference window list 
    # here we assume the test sample z has length greater than n + l
    cc_ref_windows = [Window(start=0, size=n, end=n, bins=binary_preds)]
    cc_det_window = Window(start=0, size=n, end=n, bins=binary_preds) 

    # this is the output list which consists of windows that represent an anomaly section 
    anomalies = [] 

    print("detecting anomaly sequences...") 
    while ((not ht_det_window.over()) and (not cc_det_window.over())):
        ht_cond = anomaly_detection_by_hypothesis_testing(alpha, ht_ref_window, ht_det_window)
        cc_cond = anomaly_detection_by_control_charts(cc_ref_windows, cc_det_window)
        
        # this means p value >= alpha 
        if not ht_cond:
            # we have to shift the detection window 
            ht_det_window.shift_right() 
        # this means that the formula does not hold 
        if not cc_cond:
            # we have to shift the detection window
            # and create a new reference window which
            # is the latest window created shifted right by 1 
            cc_det_window.shift_right() 
            cc_ref_windows.append(
                Window(
                start=cc_ref_windows[-1].start + 1,
                size=n,
                end=cc_ref_windows[-1].end + 1,
                bins=binary_preds
                )
            ) 

        # if both condition holds, we consider this section 
        # as an anomaly section 
        if ht_cond and cc_cond:
            anomalies.append((ht_det_window, cc_det_window)) 
             
    return anomalies 
             
    
     