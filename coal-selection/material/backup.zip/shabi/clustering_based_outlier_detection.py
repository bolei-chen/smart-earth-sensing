import numpy as np
from tqdm import tqdm 
from sklearn.cluster import KMeans 
''' 
X: training set. should be an array of samples like z
z: testing sample. the stream data where we want to detect outliers  
t: the length of X 
k: the number of clusters
s: the minimum size of a cluster accepted 
''' 
def clustering_based_outlier_detection(X, z, k, s):
    # generate all the clusters obtained from the training set X 
    print("clustering start...") 
    t = len(X) 
    clusters = generate_clusters(X, t, k, s)
    print("clustering done...") 
    print("total cluster number:", k * t) 
    print("accepted cluster number:", len(clusters)) 
    # initialize all preidictions to 0 which is normal values 
    preds = np.ones_like(z) 

    # for each sample we have in out testing set z
    # we calculate the distance between the sample and 
    # all the clusters we have
    # if the distance is greater than all existing radius
    # that means the sample is not in any of the clusters we
    # have, making itself a outlier. 
    print("predicting start...") 
    for i, sample in tqdm(enumerate(z)):
        for center, radius in clusters.items():
            distance = abs(sample - center)
            if distance <= radius:
                preds[i] = 0
    print("predictions made...") 
    return preds 

''' 
helper function for clustering_based_outlier_detection 
''' 
def generate_clusters(X, t, k, s): 
    # this is map to store clusters we generated
    # an element will be in the form of 'center:radius'
    clusters = {} 
     
    for i in range(0, t):
         
       # define k means clustering obj 
        k_means = KMeans(n_clusters=k) 
         
        # this is the training sample we are dealing with  
        curr_training_sample = X[i] 

        # we perform k means clustering on the training sample and recorde the radius 
        # and center of the clusters accepted
        # notice for a cluster to be accepted, it has to have a size greater than s 
        k_means.fit(curr_training_sample)
         
        centers = k_means.cluster_centers_ 
        preds = k_means.predict(curr_training_sample)
        sample_counts = [] 
        radius = [] 
         
        for i in range(0, len(centers)):
            # get the samples in cluster i 
            samples_clustered = [curr_training_sample[j] for j in range(0, len(curr_training_sample)) if preds[j] == i] 
            # record the number of samples inside cluster i 
            sample_counts.append(len(samples_clustered)) 
            # calculate the radius of cluster i 
            # here the radius is defined as the max
            # distance from the center to a sample inside the cluster 
            radius.append(
                max(
                    list(
                        map(
                            lambda j : abs(centers[i] - samples_clustered[j]),
                            range(0, len(samples_clustered))
                        )
                    )
                )
            )

        # here we filter out the clusters accepted 
        for i in range(0, len(sample_counts)):
            # these clusters are accepted when 
            # its size is greater than s 
            if sample_counts[i] >= s:
                clusters[float(centers[i])] = float(radius[i])
         
    return clusters 